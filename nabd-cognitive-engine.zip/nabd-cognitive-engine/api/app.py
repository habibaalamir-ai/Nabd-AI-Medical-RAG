from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List
from core.engine import NabdCognitiveEngine, SimpleVectorStore, ClinicalAssessmentReport

app = FastAPI(
    title="Nabd Cognitive Reasoning API",
    description="API for analyzing medical student clinical reasoning and detecting cognitive biases.",
    version="1.0.0"
)

# Initialize Engine
vector_store = SimpleVectorStore()
engine = NabdCognitiveEngine(vector_store=vector_store)

class StudentAssessmentRequest(BaseModel):
    case_id: str = Field(..., example="CASE_001")
    student_input: str = Field(..., example="Patient has chest pain. Diagnosis is STEMI.")
    required_labs: List[str] = Field(..., example=["12-lead ECG", "Troponin I/T"])
    required_findings: List[str] = Field(..., example=["chest pain"])
    differential_diagnoses: List[str] = Field(..., example=["STEMI"])

@app.get("/")
def read_root():
    return {"message": "Nabd Cognitive Reasoning Engine API is running smoothly."}

@app.post("/analyze", response_model=ClinicalAssessmentReport)
def analyze_case(request: StudentAssessmentRequest):
    try:
        report = engine.analyze_reasoning(
            case_id=request.case_id,
            student_input=request.student_input,
            required_labs=request.required_labs,
            required_findings=request.required_findings,
            differential_diagnoses=request.differential_diagnoses
        )
        return report
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal server error: " + str(e))
