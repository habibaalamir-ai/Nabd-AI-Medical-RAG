import pytest
from fastapi.testclient import TestClient
from api.app import app

client = TestClient(app)

def test_root_endpoint():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"message": "Nabd Cognitive Reasoning Engine API is running smoothly."}

def test_analyze_endpoint_success():
    payload = {
        "case_id": "CASE_API_01",
        "student_input": "Patient has chest pain. Ordered 12-lead ECG and Troponin test.",
        "required_labs": ["12-lead ECG", "Troponin"],
        "required_findings": ["chest pain"],
        "differential_diagnoses": ["STEMI"]
    }
    response = client.post("/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["case_id"] == "CASE_API_01"
    assert data["clinical_safety_level"] == "Safe"

def test_analyze_endpoint_invalid_input():
    payload = {
        "case_id": "",
        "student_input": "",
        "required_labs": ["ECG"],
        "required_findings": ["chest pain"],
        "differential_diagnoses": []
    }
    response = client.post("/analyze", json=payload)
    assert response.status_code == 400
