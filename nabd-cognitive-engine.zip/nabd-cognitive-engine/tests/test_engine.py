import pytest
from core.engine import NabdCognitiveEngine, SimpleVectorStore, BiasSeverity

@pytest.fixture
def setup_engine():
    vector_store = SimpleVectorStore()
    engine = NabdCognitiveEngine(vector_store=vector_store)
    return engine

def test_premature_closure_detection(setup_engine):
    engine = setup_engine
    
    report = engine.analyze_reasoning(
        case_id="CASE_TEST_01",
        student_input="The patient presents with chest pain. The diagnosis is STEMI.",
        required_labs=["12-lead ECG", "Troponin I/T"],
        required_findings=["chest pain"],
        differential_diagnoses=["STEMI"]
    )
    
    premature_bias = next(b for b in report.detected_biases if b.bias_type == "Premature Closure")
    assert premature_bias.detected is True
    assert premature_bias.severity == BiasSeverity.HIGH
    assert report.clinical_safety_level == "Critical Missing Labs"

def test_safe_assessment_without_biases(setup_engine):
    engine = setup_engine
    
    report = engine.analyze_reasoning(
        case_id="CASE_TEST_02",
        student_input="Patient presents with chest pain. Evaluated 12-lead ecg and troponin i/t.",
        required_labs=["12-lead ECG", "Troponin I/T"],
        required_findings=["chest pain"],
        differential_diagnoses=["STEMI"]
    )
    
    premature_bias = next(b for b in report.detected_biases if b.bias_type == "Premature Closure")
    assert premature_bias.detected is False
    assert report.overall_cognitive_score == 100.0
    assert report.clinical_safety_level == "Safe"

def test_invalid_empty_inputs(setup_engine):
    engine = setup_engine
    
    with pytest.raises(ValueError):
        engine.analyze_reasoning(
            case_id="",
            student_input="",
            required_labs=["ECG"],
            required_findings=["chest pain"],
            differential_diagnoses=[]
        )
