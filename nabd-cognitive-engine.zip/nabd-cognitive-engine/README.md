# 🏥 Nabd Cognitive Engine

**Nabd Cognitive Engine** is an AI-driven clinical reasoning evaluation framework designed to assess medical diagnostic steps, calculate performance metrics, and detect cognitive biases in medical education workflows.

---

## 🔑 Key Features
- **Cognitive Bias Detection**: Detects clinical reasoning failures like Premature Closure.
- **Safety Verification**: Highlights unordered or missed critical medical investigations.
- **Evidence Retrieval**: Integrates vector-based clinical knowledge matching.
- **Clean Architecture**: Standardized Object-Oriented structure using Pydantic and PyTest.

---

## 🛠️ Project Architecture

```text
nabd-cognitive-engine/
├── core/
│   ├── __init__.py
│   └── engine.py         # Diagnostic Core & Pydantic Schemas
├── api/
│   └── app.py            # FastAPI Service Endpoint
├── tests/
│   └── test_engine.py    # PyTest Suite
├── requirements.txt      # Project Dependencies
└── README.md             # Documentation
```

---

## 🚀 Quick Execution Guide

### Installation
```bash
pip install -r requirements.txt
```

### Run Unit Tests
```bash
pytest tests/
```
